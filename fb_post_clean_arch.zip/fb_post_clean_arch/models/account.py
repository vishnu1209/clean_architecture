# from django.db import models
#
#
# class Account(models.Model):
#     id = models.AutoField(primary_key=True)
#     balance = models.IntegerField(default=0)
#
