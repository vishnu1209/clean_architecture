INVALID_COMMENT_ID = (
    "Invalid comment id, try with valid comment id",
    "INVALID_COMMENT_ID"
)
INVALID_POST_ID = (
    "Invalid post id, try with valid post id",
    "INVALID_POST_ID"
)
INVALID_USER_ID = (
    "Invalid user id, try with valid user id",
    "INVALID_USER_ID"
)
INVALID_ACCESS = (
    "Access Denied",
    "INVALID_ACCESS"
)
