from enum import Enum


class ReactionType(Enum):
    LIKE = "LIKE"
    WOW = "WOW"
    HAHA = "HAHA"
    DISLIKE = "DISLIKE"
    SAD = "SAD"
    ANGRY = "ANGRY"
