- ~~create post and get post id~~
    - ~~given user_id and post_content, create comment and return id~~
   
- ~~validate post_id~~
    - ~~given invalid post_id raises exception~~
    - ~~given valid post_id not raises exception~~
    
- ~~create comment and get id~~
    - ~~given valid details create comment, return comment id~~
    
 - ~~undo post reaction~~
    - ~~given dup reaction then undo reaction type~~
    
 - **validate comment_id**
    - **given invalid comment_id raises exception**
    - given valid comment_id not raises exception