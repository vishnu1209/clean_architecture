

REQUEST_BODY_JSON = """
{
    "post_content": "string"
}
"""


RESPONSE_201_JSON = """
{
    "post_id": 1
}
"""

