

REQUEST_BODY_JSON = """
{
    "comment_text": "string"
}
"""


RESPONSE_201_JSON = """
{
    "comment_id": 1
}
"""

