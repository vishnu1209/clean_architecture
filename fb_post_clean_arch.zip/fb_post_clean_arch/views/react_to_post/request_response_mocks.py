

REQUEST_BODY_JSON = """
{
    "reaction_type": "HAHA"
}
"""


