

REQUEST_BODY_JSON = """
{
    "post_id": 1,
    "comment_text": "string"
}
"""


RESPONSE_201_JSON = """
{
    "comment_id": 1
}
"""

