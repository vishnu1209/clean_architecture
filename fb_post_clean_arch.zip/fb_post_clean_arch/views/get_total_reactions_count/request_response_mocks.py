


RESPONSE_200_JSON = """
{
    "reactions_count": 1
}
"""

