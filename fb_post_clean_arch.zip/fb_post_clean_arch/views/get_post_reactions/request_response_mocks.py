


RESPONSE_200_JSON = """
[
    {
        "user_id": 1,
        "name": "string",
        "profile_pic_url": "string",
        "reaction_type": "HAHA"
    }
]
"""

