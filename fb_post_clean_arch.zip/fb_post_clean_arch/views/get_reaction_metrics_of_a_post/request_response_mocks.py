


RESPONSE_200_JSON = """
[
    {
        "reaction_type": "HAHA",
        "reaction_count": 1
    }
]
"""

