


RESPONSE_200_JSON = """
[
    {
        "comment_id": 1,
        "commenter": {
            "user_id": 1,
            "name": "string",
            "profile_pic_url": "string"
        },
        "commented_at": "2099-12-31 00:00:00",
        "comment_content": "string"
    }
]
"""

