from django.apps import AppConfig


class FbPostCleanArchAppConfig(AppConfig):
    name = "fb_post_clean_arch"

    def ready(self):
        pass
