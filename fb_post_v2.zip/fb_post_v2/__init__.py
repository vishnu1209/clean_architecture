default_app_config = "fb_post_v2.app.FbPostV2AppConfig" # pylint:disable=invalid-name

EXECUTE_API_TEST_CASE = True
__version__ = '0.0.1'
