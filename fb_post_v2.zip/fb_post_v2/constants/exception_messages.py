INVALID_OFFSET_LENGTH = (
    'Offset should be greater than or equal to zero and length should be '
    'greater than zero', 'INVALID_OFFSET_LENGTH'
)
